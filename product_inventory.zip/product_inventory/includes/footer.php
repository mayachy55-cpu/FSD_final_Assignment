</div>

<footer
    style="text-align: center; padding: 2rem 0; color: var(--text-muted); font-size: 0.875rem; border-top: 1px solid var(--border-color); margin-top: 3rem;">
    ©
    <?= date('Y') ?> Product Inventory System. All rights reserved.
</footer>

<script src="<?= $baseUrl ?>/assets/js/script.js"></script>
</body>

</html>